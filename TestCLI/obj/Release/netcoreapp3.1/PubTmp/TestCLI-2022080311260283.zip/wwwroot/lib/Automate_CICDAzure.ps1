# Replace the following URL with a public GitHub repo URL
$gitrepo="stry"
$gittoken="isat"
$webappname="svcname$(Get-Random)"
$location="West Europe" 
$rgName="resgroup"
$branch="sourcebrnch"
$azureorgst="azorg"
$azuretoken="aztoken"
$azurerepo="azrepon"
$azureprj="azprjc"



Install-Module Az
Import-Module Az






Connect-AzAccount

az login;
az appservice plan create --name  $webappname --resource-group  $rgName  --sku  FREE

az webapp create --name $webappname --resource-group $rgName --plan $webappname


