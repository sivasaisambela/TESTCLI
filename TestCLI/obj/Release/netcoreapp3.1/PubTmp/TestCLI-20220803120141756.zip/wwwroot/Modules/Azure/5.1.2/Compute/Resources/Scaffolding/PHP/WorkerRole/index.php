<?php
 sleep(3600);
?>