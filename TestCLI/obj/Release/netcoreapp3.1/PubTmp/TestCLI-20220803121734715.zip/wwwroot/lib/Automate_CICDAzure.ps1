# Replace the following URL with a public GitHub repo URL
$gitrepo="stry"
$gittoken="isat"
$webappname="svcname$(Get-Random)"
$location="West Europe" 
$rgName="resgroup"
$branch="sourcebrnch"
$azureorgst="azorg"
$azuretoken="aztoken"
$azurerepo="azrepon"
$azureprj="azprjc"

Set-ExecutionPolicy RemoteSigned 




Install-Module -Name C:\home\site\wwwroot\wwwroot\Modules\Azure -AllowClobber -Scope CurrentUser






Connect-AzAccount

az login;
az appservice plan create --name  $webappname --resource-group  $rgName  --sku  FREE

az webapp create --name $webappname --resource-group $rgName --plan $webappname


